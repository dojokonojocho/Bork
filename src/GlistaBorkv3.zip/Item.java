import java.util.*;
import java.io.*;
public class Item {
	private String primaryName;
	private int weight;
	private Hashtable<String, String> messages = new Hashtable<String, String>();
	
	public Item(Scanner s) {
		primaryName = s.nextLine();
		if (!primaryName.equals("===")) {
			weight = s.nextInt();
			boolean swtch = true;
			String action = "";
			s.nextLine();
			while(swtch){
				action = s.nextLine();
				if (!action.equals("---")) {
					String[] message = action.split(":");
					messages.put(message[0], message[1]);
				} else {
					swtch = false;
				}
			}
		}
	}
	public Item() {
		
	}
	public boolean goesBy(String name) {
		if (name.equals(primaryName))
			return true;
		return false;
	}
	public String getPrimaryName() {
		return primaryName;
	}
	public String getMessageForString(String verb) {
		return messages.get(verb);
	}
	//public String toString(){
	//	return null;
	//}
	
}

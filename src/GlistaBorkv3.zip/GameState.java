import java.util.*;
import java.io.*;
class GameState {
	private Room currentRoom;
	private Dungeon currentDungeon;
	private ArrayList<Item> inventory = new ArrayList<Item>();
	private String initFileName;
	public boolean hasSaved = true;
	private boolean initEntry = true;
	private static GameState g = null;
	private GameState() {
		
	}
	public static GameState instance() {
		if (g == null) {
			g = new GameState();
		}
		return g;
	}
	
	public void initialize(Dungeon dungeon) {
		currentDungeon = dungeon;
		if (initEntry) {
			currentRoom = currentDungeon.getEntry();
		}
		System.out.println("Welcome adventurer to the " + dungeon.getName() + " dungeon");
		System.out.println(currentRoom.describe());
		System.out.println("Type 'help' for a list if commands.");
	}
	public Room getAdventurersCurrentRoom() {
		return currentRoom;
	}
	public void setAdventurersCurrentRoom(Room room) {
		currentRoom = room;
	}
	public String getInitFileName() {
		return initFileName;
	}
	public void setInitFileName(String name) {
		this.initFileName = name;
	}
	public Dungeon getDungeon() {
		return currentDungeon;
	}
	ArrayList<String> getInventoryNames(){
		ArrayList<String> invString = new ArrayList<String>();
		for (int i = 0; i < inventory.size(); i++) {
			invString.add(inventory.get(i).getPrimaryName());
		}
		return invString;
	}
	void addToInventory(Item item){
		inventory.add(item);
	}
	void removeFromInventory(Item item) {
		for (int i = 0; i < inventory.size(); i++) {
			if (inventory.get(i) == item) {
				inventory.remove(i);
			}
		}
	}
	Item getItemInVicinityNamed(String name) {
		if (!inventory.isEmpty()) {
			for (int i = 0; i < inventory.size(); i++) {
				if (inventory.get(i).getPrimaryName().equals(name)) {
					return inventory.get(i);
				}
			}
		} else {
			
		}
		Item item = getAdventurersCurrentRoom().getItemNamed(name);
		return item;
	}
	Item getItemInInventoryNamed(String name) {
		if (!inventory.isEmpty()) {
			for (int i = 0; i < inventory.size(); i++) {
				if (inventory.get(i).getPrimaryName().equals(name)) {
					return inventory.get(i);
				}
			}
			System.out.println("You are not holding a " + name);
		} else {
			System.out.println("You are not holding any item");
		}
		return null;
	}
	String showInventory() {
		String inv = "Inventory: ";
		if (!inventory.isEmpty()) {
			for (int i = 0; i < inventory.size(); i++) {
				if (i > 0) {
					inv += ",";
				}
				inv += inventory.get(i).getPrimaryName();
			}
			return inv;
		}
		return "You are currently holding nothing";
	}
	void store(String saveName) {
		try {
			PrintWriter pw = new PrintWriter(saveName);
			pw.println("Bork v3.0");
			currentDungeon.storeState(pw);
			pw.println("Adventurer:");
			pw.println("Current room: " + this.getAdventurersCurrentRoom().getTitle());
			String listOfItems = "Inventory: ";
			if (inventory != null){
				for (int i = 0; i < inventory.size(); i++) {
					if (i > 0) {
						listOfItems += ",";
					}
					listOfItems += inventory.get(i).getPrimaryName();
				}
				pw.println(listOfItems);
			}
			pw.close();
		} catch (IOException e) {
			System.err.println("An IOException occured while saving");
		}
		try        
		{
			for (int i = 0; i < 11; i++) {
				Thread.sleep(90);
				System.out.print(".");
			}
		    Thread.sleep(90);
		    System.out.print("\n");
		    Thread.sleep(1200);
		    System.out.println("File successfully saved to " + saveName);
		} 
		catch(InterruptedException ex) 
		{
		    Thread.currentThread().interrupt();
		}
		
	}
	void restore(String fileName) {
		try {
			FileReader fr = new FileReader(fileName);
			Scanner sc = new Scanner(fr);
			if (!sc.nextLine().equals("Bork v3.0")) {
				System.out.println("The .sav file is incompatible with this version of Bork");
				System.out.println("Terminating bork engine");
				System.exit(0);
			}
			String[] dngName = sc.nextLine().split(":");
			String borkName = dngName[1].substring(1);
			currentDungeon = new Dungeon(borkName, false);
			currentDungeon.restoreState(sc);
			sc.nextLine();
			String[] currentRoomArray = sc.nextLine().split(":");
			currentRoom = currentDungeon.getRoom(currentRoomArray[1].substring(1));
			try {
				String[] invTemp = sc.nextLine().split(" ");
				if (invTemp[1].contains(",")) {
					String[] inv = invTemp[1].split(",");
					for (String s : inv) {
						inventory.add(currentDungeon.getItem(s));
					}
				} else {
					inventory.add(currentDungeon.getItem(invTemp[1]));
				}
			} catch (IndexOutOfBoundsException e) {
				
			}
			initEntry = false;
			sc.close();
		} catch (IOException e) {
			System.err.println("File not found");
			System.exit(0);
		} 
		this.initialize(currentDungeon);
	}
}


class ItemSpecificCommand extends Command{
	private String verb;
	private String noun;
	private Item item;
	ItemSpecificCommand(String verb, String noun){
		this.verb = verb;
		this.noun = noun;
	}
	String execute() {
		GameState gs = GameState.instance();
		item = gs.getItemInVicinityNamed(noun);
		if (item != null) {
			String temp = item.getMessageForString(verb);
			if (temp != null) {
				System.out.println(item.getMessageForString(verb));
			} else {
				System.out.println("You can't "+ verb + " a " + noun);
			}
		} 
		return null;
	}
}

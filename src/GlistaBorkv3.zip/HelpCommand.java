
class HelpCommand extends Command{	
	HelpCommand(){
	}
	String execute() {
		System.out.println("LIST OF COMMANDS");
		System.out.println("MOVEMENT:  'n'-NORTH 's'-SOUTH 'w'-WEST 'e'-EAST 'u'-UP 'd'-DOWN ");
		System.out.println("ITEMS:     'i' or 'inventory'-Displays the users current held items");
		System.out.println("           'take (item)'-Adds item from current room to your inventory");
		System.out.println("GAMESTATE: 'q'-Exits the game");
		System.out.println("           'qq'- Save and exit the game. Saves to currently opened .sav file, or creates new .sav file if current file is .bork");
		System.out.println("           'save'-Saves to default file name('save1.sav')");
		System.out.println("           'save (fileName.sav)'-Saves to user specified .sav file");
		System.out.println("           'delete (fileName.sav)'-Deletes user specified .sav file");
		return null;
	}
}

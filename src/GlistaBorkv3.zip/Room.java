import java.io.PrintWriter;
import java.util.*;
import java.util.*;
public class Room {
	private String title = "";
	private String desc = "";
	private String listOfExits;
	private boolean beenHere = false;
	private ArrayList<Exit> exits = new ArrayList<Exit>();
	private ArrayList<Item> items = new ArrayList<Item>();
	
	public Room(Scanner s, Dungeon thisDungeon, boolean initState) {
		if (s.hasNextLine()) {
			title = s.nextLine();
		}
		if (!title.equals("===")) {
			String temp = s.nextLine();
			if (temp.startsWith("Contents:") && initState) {
				String[] throwAway = temp.split(" ");
				if (throwAway[1].contains(",")) {
					String[] listOfItems = throwAway[1].split(",");
					for (int i = 0; i < listOfItems.length; i++) {
						items.add(thisDungeon.getItem(listOfItems[i]));
					}
				} else {
					String itemName = throwAway[1];
					items.add(thisDungeon.getItem(itemName));
				}
				temp = s.nextLine();
			}
			GameState gs = GameState.instance();
			if (!initState && temp.startsWith("Contents:")) {
				if (gs.getInitFileName().substring(gs.getInitFileName().lastIndexOf(".")+1).equals("sav")) {
					temp = s.nextLine();
				}
			}
			boolean swtch = true;
			boolean first = true;
			while (swtch) {
				if (!first) {
					temp = s.nextLine();
				} else {
					first = false;
				}
				if (!temp.equals("---")) {
					setDesc(temp + " ");
				} else {
					swtch = false;
				}
			}
		}
	}
	public Room(String title) {
		this.title = title;
	}
	public String getTitle() {
		return title;
	}
	public void setListOfExits(String listOfExits) {
		this.listOfExits = listOfExits;
	}
	public void setDesc(String tempDesc) {
		this.desc += tempDesc;
	}
	public String describe() {
		if (beenHere == false) {
			beenHere = true;
			if (items.isEmpty()) {
				return title + "\n" + desc + "\n" + descExits(exits);
			} 
			return title + "\n" + desc + "\n" + descExits(exits) + "\n" + descItems();
		}
		if (items.isEmpty()) {
			return title + "\n" + descExits(exits);
		}
		return title + "\n" + descExits(exits) + "\n" + descItems();
		
	}
	void add(Exit exit) {
		
	}
	void remove(Item item) {
		for (int i = 0; i < items.size(); i++) {
			if (items.get(i) == item) {
				items.remove(i);
			}
		}
	}
	void addItem(Item item) {
		items.add(item);
	}
	public Item getItemNamed(String name) {
		GameState gs = GameState.instance();
		ArrayList<String> invString = gs.getInventoryNames();
		if (invString.contains(name)) {
			System.out.println("You are already carrying " + name);
		} else if (!items.isEmpty()) {
			for (int i = 0; i < items.size(); i++) {
				if (items.get(i).getPrimaryName().equals(name)) {
					return items.get(i);
				}
			}
			System.out.println("There is no " + name + " here");
		} else {
			System.out.println("This room is empty");
		}
		return null;
	}
	ArrayList<Item> getContent(){
		return items;
	}
	public String descExits(ArrayList<Exit> exits) {
		String exitDesc = "";
		for (int i = 0; i < exits.size(); i++) {	
			exitDesc += exits.get(i).descibe();
		}
		return exitDesc;
	}
	public String descItems() {
		String itemDesc = "";
		for (int i = 0; i < items.size(); i++) {
			itemDesc += "There is a " + items.get(i).getPrimaryName() + " here. ";
		}
		return itemDesc;
	}
	public Room leaveBy(String dir) {
		for (int i = 0; i < exits.size(); i++) {
			if (exits.get(i).getDir().equals(dir)) {
				System.out.println(exits.get(i).getDest().describe());
				return exits.get(i).getDest();
			}
		}
		System.out.println(this.getTitle() + " has no exit in that direction");
		return exits.get(0).getSrc();
	}
	public void addExit(Exit exit) {
		exits.add(exit);
	}
	void storeState(PrintWriter pw) {
		pw.println(this.getTitle() + ":");
		pw.println("beenHere=" + beenHere);
		if (!items.isEmpty()) {
			String setOfItems = "Contents: ";
			for (int i = 0; i < items.size(); i++) {
				if (i > 0) {
					setOfItems += ",";
				}
				setOfItems += items.get(i).getPrimaryName();
			}
			pw.println(setOfItems);
		}
		pw.println("---");
	}
	void restoreState(Scanner sc, Dungeon d) {
		String[] beenHereArray = sc.nextLine().split("=");
		if (beenHereArray[1].equals("true")) {
			beenHere = true;
		} else if(beenHereArray[1].equals("false")) {
			beenHere = false;
		} else {
			System.out.println("No boolean value could be found for" + this.getTitle());
		}
		String temp = sc.nextLine();
		if (temp.startsWith("Contents: ")) {
			String[] throwAway = temp.split(" ");
			if (throwAway[1].contains(",")) {
				String[] itemList = throwAway[1].split(",");
				for (int i = 0; i < itemList.length; i++) {
					items.add(d.getItem(itemList[i]));
				}
			} else {
				String itemName = throwAway[1];
				items.add(d.getItem(itemName));
			}
			sc.nextLine();
		}
	}
	
	class NoRoomException{
		
	}
	
	
}

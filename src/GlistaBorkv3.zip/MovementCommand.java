
class MovementCommand extends Command{
	private String dir;
	
	MovementCommand(String dir) {
		this.dir = dir;
	}
	String execute() {
		if (dir.equals("n")) {
			GameState gs = GameState.instance();
			Room current = gs.getAdventurersCurrentRoom();
			Room newRoom = current.leaveBy("n");
			gs.setAdventurersCurrentRoom(newRoom);
			gs.hasSaved = false;
		} else if (dir.equals("s")) {
			GameState gs = GameState.instance();
			Room current = gs.getAdventurersCurrentRoom();
			Room newRoom = current.leaveBy("s");
			gs.setAdventurersCurrentRoom(newRoom);
			gs.hasSaved = false;
		} else if (dir.equals("e")) {
			GameState gs = GameState.instance();
			Room current = gs.getAdventurersCurrentRoom();
			Room newRoom = current.leaveBy("e");
			gs.setAdventurersCurrentRoom(newRoom);
			gs.hasSaved = false;
		} else if (dir.equals("w")) {
			GameState gs = GameState.instance();
			Room current = gs.getAdventurersCurrentRoom();
			Room newRoom = current.leaveBy("w");
			gs.setAdventurersCurrentRoom(newRoom);
			gs.hasSaved = false;
		} else if (dir.equals("u")) {
			GameState gs = GameState.instance();
			Room current = gs.getAdventurersCurrentRoom();
			Room newRoom = current.leaveBy("u");
			gs.setAdventurersCurrentRoom(newRoom);
			gs.hasSaved = false;
		} else if (dir.equals("d")) {
			GameState gs = GameState.instance();
			Room current = gs.getAdventurersCurrentRoom();
			Room newRoom = current.leaveBy("d");
			gs.setAdventurersCurrentRoom(newRoom);
			gs.hasSaved = false;
		}
		
		return null;
	}
}

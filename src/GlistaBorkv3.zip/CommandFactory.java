
class CommandFactory {
	private static CommandFactory c = null;
	private CommandFactory() {
		
	}
	public static CommandFactory instance() {
		if (c == null) {
			c = new CommandFactory();
		}
		return c;
	}

	public void parse(String commandString) {
		Command userInput = null;
			if ((commandString.equals("n"))||(commandString.equals("s"))||(commandString.equals("e"))||(commandString.equals("w"))||(commandString.equals("u"))||(commandString.equals("d"))) {
				userInput = new MovementCommand(commandString);
			} else if (commandString.startsWith("save")){
				userInput = new SaveCommand(commandString);
			} else if (commandString.equals("help")) {
				userInput = new HelpCommand();
			} else if (commandString.startsWith("delete")) {
				userInput = new DeleteCommand(commandString);
			} else if (commandString.equals("qq")) {
				userInput = new QuickExitCommand();
			} else if (commandString.equals("i") || commandString.equals("inventory")) {
				userInput = new InventoryCommand();
			} else if (commandString.startsWith("take")) {
				userInput = new TakeCommand(commandString);
			} else if (commandString.startsWith("drop")) {
				userInput = new DropCommand(commandString);
			} else {
				String[] temp = null;
				boolean un = true;
				try {
					temp = commandString.split(" ");
					if (temp.length == 2) {
						userInput = new ItemSpecificCommand(temp[0], temp[1]);
						un = false;
					}
				} catch (IndexOutOfBoundsException e) {
					
				} 
				if (un)
					userInput = new UnknownCommand(commandString);
			}
			if (userInput != null) {
				userInput.execute();
			}
	}
}


class CommandFactory {
	private static CommandFactory c = null;
	private CommandFactory() {
		
	}
	public static CommandFactory instance() {
		if (c == null) {
			c = new CommandFactory();
		}
		return c;
	}

	public void parse(String commandString) {
			Command userInput = new Command(commandString);
			userInput.execute();
	}
}

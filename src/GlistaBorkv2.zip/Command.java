
class Command {
	private String input;
	
	Command(String input) {
		this.input = input;
	}
	public String execute() {
		if (input.equals("n")) {
			GameState gs = GameState.instance();
			Room current = gs.getAdventurersCurrentRoom();
			Room newRoom = current.leaveBy("n");
			gs.setAdventurersCurrentRoom(newRoom);
		} else if (input.equals("s")) {
			GameState gs = GameState.instance();
			Room current = gs.getAdventurersCurrentRoom();
			Room newRoom = current.leaveBy("s");
			gs.setAdventurersCurrentRoom(newRoom);
		} else if (input.equals("e")) {
			GameState gs = GameState.instance();
			Room current = gs.getAdventurersCurrentRoom();
			Room newRoom = current.leaveBy("e");
			gs.setAdventurersCurrentRoom(newRoom);
		} else if (input.equals("w")) {
			GameState gs = GameState.instance();
			Room current = gs.getAdventurersCurrentRoom();
			Room newRoom = current.leaveBy("w");
			gs.setAdventurersCurrentRoom(newRoom);
		} else if (input.equals("u")) {
			GameState gs = GameState.instance();
			Room current = gs.getAdventurersCurrentRoom();
			Room newRoom = current.leaveBy("u");
			gs.setAdventurersCurrentRoom(newRoom);
		} else if (input.equals("d")) {
			GameState gs = GameState.instance();
			Room current = gs.getAdventurersCurrentRoom();
			Room newRoom = current.leaveBy("d");
			gs.setAdventurersCurrentRoom(newRoom);
		} else if (input.equals("save")) {
			GameState gs = GameState.instance();
			gs.store("save1.sav");
		} else if (input.startsWith("save ")) {
			GameState gs = GameState.instance();
			String[] temp = input.split(" ");
			if (temp[1].substring(temp[1].lastIndexOf(".")+1).equals("sav")) {
				gs.store(temp[1]);
			} else {
				System.err.println(temp[1] + " does not contian .sav file extention");
			}
		} else if(input.equals("help")) {
			System.out.println("LIST OF COMMANDS");
			System.out.println("MOVEMENT:  'n'-NORTH 's'-SOUTH 'w'-WEST 'e'-EAST 'u'-UP 'd'-DOWN ");
			System.out.println("GAMESTATE: 'q'-Exits the game");
			System.out.println("           'save'-saves to default location('save1.sav')");
			System.out.println("           'save (arg)'-saves to specified location. (arg) is file name with .sav extension");
		} else {
			System.out.println(input + " is not a valid command");
		}
		
		return null;
	}
}

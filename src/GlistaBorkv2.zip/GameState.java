import java.util.*;
import java.io.*;
class GameState {
	private Room currentRoom;
	private Dungeon currentDungeon;
	private boolean initEntry = true;
	private static GameState g = null;
	private GameState() {
		
	}
	public static GameState instance() {
		if (g == null) {
			g = new GameState();
		}
		return g;
	}
	
	public void initialize(Dungeon dungeon) {
		currentDungeon = dungeon;
		if (initEntry) {
			currentRoom = currentDungeon.getEntry();
		}
		System.out.println("Welcome adventurer to the " + dungeon.getName() + " dungeon");
		System.out.println(currentRoom.describe());
		System.out.println("Type 'help' for a list if commands.");
	}
	public Room getAdventurersCurrentRoom() {
		return currentRoom;
	}
	public void setAdventurersCurrentRoom(Room room) {
		currentRoom = room;
	}
	public Dungeon getDungeon() {
		return currentDungeon;
	}
	void store(String saveName) {
		try {
			PrintWriter pw = new PrintWriter(saveName);
			pw.println("Bork v2");
			currentDungeon.storeState(pw);
			pw.write("Current room: " + this.getAdventurersCurrentRoom().getTitle());
			pw.close();
		} catch (IOException e) {
			System.err.println("An IOException occured while saving");
		}
		
	}
	void restore(String fileName) {
		try {
			FileReader fr = new FileReader(fileName);
			Scanner sc = new Scanner(fr);
			if (!sc.nextLine().equals("Bork v2")) {
				System.err.println("The .sav file is incompatible with this version of Bork");
				System.exit(0);
			}
			String[] dngName = sc.nextLine().split(":");
			String borkName = dngName[1].substring(1);
			currentDungeon = new Dungeon(borkName);
			currentDungeon.restoreState(sc);
			String[] currentRoomArray = sc.nextLine().split(":");
			currentRoom = currentDungeon.getRoom(currentRoomArray[1].substring(1));
			initEntry = false;
			sc.close();
		} catch (IOException e) {
			e.getStackTrace();
		}
		this.initialize(currentDungeon);
	}
}

import java.io.*;
import java.util.*;
class Interpreter {
	public static void main(String[] args) {
		
		InputStreamReader isr = new InputStreamReader(System.in);
	    BufferedReader br = new BufferedReader(isr);   
	   
		Boolean swtch = true;
		while (swtch) {
			Scanner in = new Scanner(System.in);
			System.out.println("Enter file name");
			String fileName = in.next();
			if (fileName.substring(fileName.lastIndexOf(".")+1).equals("bork")) {
				Dungeon Dungeon1 = new Dungeon(fileName);
			    GameState gs = GameState.instance();
				gs.initialize(Dungeon1);
				swtch = false;
			} else if (fileName.substring(fileName.lastIndexOf(".")+1).equals("sav")) {
			    GameState gs = GameState.instance();
				gs.restore(fileName);
				swtch = false;
			} else {
				System.out.println(fileName + " file is not a valid format. Please enter a file with a .bork or .sav extension.");
			}
		}
		CommandFactory cf = CommandFactory.instance();
	    
		
	    String userInput = "";
	    do {
		userInput = promptUser(br);
		if (!userInput.equals("q"))
			cf.parse(userInput);
	    } while (!userInput.equals("q"));
		
	}	

	private static String promptUser(BufferedReader commandLine) {
		System.out.println("Enter new line:");
		String userInput = "";
		try {
			String line = "";
	        while ((line = commandLine.readLine()) != null) {
	        	userInput += line;
	        	return userInput;
	        }

	        commandLine.close();
		} catch(IOException e) {
			System.err.println("No input found");
		}
		return userInput;
	}

}

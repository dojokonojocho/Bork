
public class Exit {
	private String dir;
	private Room src;
	private Room dest;
	
	public Exit(String dir, Room src, Room dest) {
		this.dir = dir;
		this.src = src;
		this.dest = dest;
	}
	public String descibe() {
		return null;
	}
	public String getDir() {
		return dir;
	}
	public Room getSrc() {
		return src;
	}
	public Room getDest() {
		return dest;
	}
}

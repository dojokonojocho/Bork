import java.util.*;
public class Dungeon {
	private String name;
	private Room entry;
	private Hashtable<String, Room> rooms = new Hashtable<String, Room>();
	
	
	public Dungeon(Room entry, String name) {
		this.entry = entry;
		this.name = name;
		rooms.put(entry.getTitle(), entry);
	}
	public Room getEntry() {
		return entry;
	}
	public String getName() {
		return name;
	}
	public void add(Room room) {
		rooms.put(room.getTitle(), room);
	}
	public Room getRoom(String roomTitle) {
		return rooms.get(roomTitle);
	}
}


class Command {
	private String dir;
	
	Command(String dir) {
		this.dir = dir;
	}
	public String execute() {
		GameState gs = GameState.instance();
		Room current = gs.getAdventurersCurrentRoom();
		Room newRoom = current.leaveBy(dir);
		gs.setAdventurersCurrentRoom(newRoom);
		return null;
	}
}

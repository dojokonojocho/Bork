
class CommandFactory {
	private static CommandFactory c = null;
	private CommandFactory() {
		
	}
	public static CommandFactory instance() {
		if (c == null) {
			c = new CommandFactory();
		}
		return c;
	}

	public void parse(String commandString) {
		//if (commandString.equals("n") || (commandString.equals("s"))  || (commandString.equals("e"))  || (commandString.equals("w"))  || (commandString.equals("u"))  || (commandString.equals("d"))){
			//Command move = new Command(commandString);
			//move.execute();
		if (commandString.equals("n")) {
			Command move = new Command("n");
			move.execute();
		} else if (commandString.equals("s")) {
			Command move = new Command("s");
			move.execute();
		} else if (commandString.equals("w")) {
			Command move = new Command("w");
			move.execute();
		} else if (commandString.equals("e")) {
			Command move = new Command("e");
			move.execute();
		} else {
			System.out.println(commandString + " is not a valid command");
		}
	}
}

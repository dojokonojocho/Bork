import java.io.*;
import java.util.*;
class Interpreter {
	public static void main(String[] args) {
		
		
	    Dungeon tDungeon = buildSampleDungeon();
		GameState gs = GameState.instance();
		gs.initialize(tDungeon);
		CommandFactory cf = CommandFactory.instance();
		
	    
		InputStreamReader isr = new InputStreamReader(System.in);
	    BufferedReader br = new BufferedReader(isr);
	    String userInput = "";
	    do {
		userInput = promptUser(br);
		if (!userInput.equals("q"))
			cf.parse(userInput);
	    } while (!userInput.equals("q"));
		
	}	

	private static String promptUser(BufferedReader commandLine) {
		System.out.println("Enter new line:");
		String userInput = "";
		try {
			String line = "";
	        while ((line = commandLine.readLine()) != null) {
	        	userInput += line;
	        	return userInput;
	        }

	        commandLine.close();
		} catch(IOException e) {
			System.err.println("No input found");
		}
		return userInput;
	}
	private static Dungeon buildSampleDungeon() {
		Room lobby = new Room("Main Lobby");
		lobby.setDesc("The lobby is very clean with a receptionist desk in the middle.");
		lobby.setListOfExits("There exists a stairwell to the NORTH and a hallway that stretches to the EAST and to the WEST");
		Room stairs = new Room("Stairwell");
		stairs.setDesc("It smells of indutrial cleaner and you can hear footsteps clumping down somewhere upstairs.");
		stairs.setListOfExits("Going UP leads to the 2nd floor. The lobby is to the SOUTH");
		Room westSide = new Room ("West Hallway");
		westSide.setDesc("Posters line the walls with messages of upcoming events. Further down the corridor you see many rooms on either side.");
		westSide.setListOfExits("To the NORTH there is a door that leads outside. The lobby is behind you to the EAST");
		Room eastSide = new Room("East Hallway");
		eastSide.setDesc("Students are walking thoughout the hall, trying to get to their respective rooms.");
		eastSide.setListOfExits("To the NORTH there is a door that leads outside. The lobby is behind you to the EAST");
		Room eagleBack = new Room ("Back of Eagle");
		eagleBack.setDesc("Its a tad grimy back here. There is a generator and some empty parking spots. The doors back into Eagle are locked on this side.");
		eagleBack.setListOfExits("SOUTH is the courtyard, while there is a parking garage to the WEST.\\nGoing EAST brings you around to the front of Eagle(Currently leads back to lobby).");
		Dungeon tDungeon = new Dungeon(lobby, "Eagle Landing");
		tDungeon.add(stairs);
		tDungeon.add(westSide);
		tDungeon.add(eastSide);
		tDungeon.add(eagleBack);
		Exit lobby_N = new Exit("n", lobby, stairs);
		Exit lobby_W = new Exit("w", lobby, westSide);
		Exit lobby_E = new Exit("e", lobby, eastSide);
		Exit stairs_S = new Exit("s", stairs, lobby);
		Exit westSide_E = new Exit("e", westSide, lobby);
		Exit westSide_N = new Exit("n", westSide, eagleBack);
		Exit eastSide_W = new Exit("w", eastSide, lobby);
		Exit eastSide_N = new Exit("n", eastSide, eagleBack);
		Exit eagleBack_E = new Exit("e", eagleBack, lobby);
		lobby.addExit(lobby_N);
		lobby.addExit(lobby_W);
		lobby.addExit(lobby_E);
		stairs.addExit(stairs_S);
		westSide.addExit(westSide_N);
		westSide.addExit(westSide_E);
		eastSide.addExit(eastSide_N);
		eastSide.addExit(eastSide_W);
		eagleBack.addExit(eagleBack_E);
		
		
		System.out.println("Welcome to " + tDungeon.getName());
		System.out.println(tDungeon.getRoom("Main Lobby").describe());
		return tDungeon;
	}
}

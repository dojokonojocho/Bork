import java.util.*;
public class Room {
	private String title;
	private String desc;
	private String listOfExits;
	private boolean beenHere = false;
	private ArrayList<Exit> exits = new ArrayList<Exit>();
	
	public Room() {
		
	}
	public Room(String title) {
		this.title = title;
	}
	public String getTitle() {
		return title;
	}
	public void setListOfExits(String listOfExits) {
		this.listOfExits = listOfExits;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public String describe() {
		if (beenHere == false) {
			beenHere = true;
			return title + "\n" + desc + "\n" + listOfExits;
		}
		return title + "\n" + listOfExits;
	}
	public Room leaveBy(String dir) {
		for (int i = 0; i < exits.size(); i++) {
			if (exits.get(i).getDir() == dir) {
				System.out.println(exits.get(i).getDest().describe());
				return exits.get(i).getDest();
			}
		}
		System.out.println(this.getTitle() + " has no exit in that direction");
		return exits.get(0).getSrc();
	}
	public void addExit(Exit exit) {
		exits.add(exit);
	}
	public static void main(String[] args) {
		Room tRoom = new Room("Test Room");
		tRoom.setDesc("There is an exit to the north");
		Room tRoom2 = new Room ("Test Room 2");
		tRoom2.setDesc("There is an exit to the south");
		Exit nExit = new Exit("n", tRoom, tRoom2);
		tRoom.addExit(nExit);
		Exit sExit = new Exit("s", tRoom2, tRoom);
		tRoom2.addExit(sExit);
		System.out.println(tRoom.describe());
		tRoom.leaveBy("n");
		tRoom2.leaveBy("s");
	}
	
}


class GameState {
	private Room currentRoom;
	private Dungeon currentDungeon;
	private static GameState g = null;
	private GameState() {
		
	}
	public static GameState instance() {
		if (g == null) {
			g = new GameState();
		}
		return g;
	}
	
	public void initialize(Dungeon dungeon) {
		currentDungeon = dungeon;
		currentRoom = currentDungeon.getEntry();
	}
	public Room getAdventurersCurrentRoom() {
		return currentRoom;
	}
	public void setAdventurersCurrentRoom(Room room) {
		currentRoom = room;
	}
	public Dungeon getDungeon() {
		return currentDungeon;
	}
}
